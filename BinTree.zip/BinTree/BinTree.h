//header para arvore binaria de busca simples

#include <stdlib.h>

//codigo para limpar a tela
#define CLEAR "\033[0;0;0m"
#define RESET "\033[0m"
#define BYELLOW_GREEN_BOLD "\033[93;42;1m"

//Definição do tipo de dado armazenado na arvore
typedef unsigned Tdado; //se precisar mudar o tipo muda aqui ao inves de mudar o codigo inteiro

//Definição da estrutura nó de árvore
typedef struct TreeNode{
    Tdado info;  //dado armazenado no nó
    struct TreeNode *left;  //ponteiro para o ramo esquerdo
    struct TreeNode *right; //ponteiro para o ramo direito                                   _ 
} TreeNode;                                                       //treenode->      | left | info | right |

//Função de inserção
TreeNode* insertBinTree(Tdado x, TreeNode *bt);

//função de remoção por merge(promoção de um dos filhos)
TreeNode *deleteTree(TreeNode *bt, Tdado x);

//valor minimo de uma arvore
Tdado minTree(TreeNode *bt); 

//remoção por copia     //ou o filho mais à direita do ramo esquerdo || ramo mais à esquerda do ramo direito e substiui a raiz, remove a folha que substituiu a raiz
TreeNode* delTree(TreeNode *bt, Tdado x);

//função de impressão
void printBinTree(const TreeNode *bt, int level);

//freeBinTree: apaga toda a arvore com raiz em bt
void freeBinTree(TreeNode* bt);

//preordem: percorre toda a arvore em preordem
void preOrdem(TreeNode* bt);

//em ordem: percorre toda a arvore em ordem
void emOrdem(TreeNode* bt);

//pos ordem: percorre toda a arvore em pos ordem
void posOrdem(TreeNode* bt);

//height: calcula a altura da arvore
int height(TreeNode* bt);

//width: calcula a largura da arvore
int width(TreeNode* bt);

//isleaf: verifica se o nó é uma folha
int isleaf(TreeNode* bt);

//numnodes: conta o numero de nós
int numNodes(TreeNode* bt);





















































































































