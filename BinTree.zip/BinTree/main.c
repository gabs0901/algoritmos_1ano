#include <stdio.h>
#include "BinTree.h"
//#include "BinTree.c"

void clear(){
    printf("\033[h\033[2j");    //escape codes para limpar a tela (unix)
}


//------------
//função main
//------------

int main(){
    TreeNode *bt = NULL;
    int op = 0, v = 0;

    do{
        clear();
        printf("Arvore atual:\n\n");
        printBinTree(bt, 0);    
        printf("\nPercurso em pre ordem: ");
        preOrdem(bt);
        printf("\n\n");
        printf("\nPercurso em ordem: ");
        emOrdem(bt);
        printf("\n\n");
        printf("\nPercurso em pos ordem: ");
        posOrdem(bt);
        printf("\n\n");    
/*      
        printf("Altura da arvore = %d\n\n", height(bt));
        printf("Largura da arvore = %d\n\n", width(bt));
        printf("Numero de nos: %d\n\n", numNodes(bt));
*/
        printf("Selecione a opção desejada:\n");
        printf("(0)sair\n");
        printf("(1)inserir\n");
        printf("(2)remoção por merge\n");
        printf("(3)remoção por cópia\n");
        printf("Opção >> ");
        scanf("%d", &op);
        switch(op){
            case 0:
                printf("Programa encerrado!\n"); break;
            case 1: 
                printf("Qual valor? >> ");  
                scanf("%d", &v);
                bt = insertBinTree(v, bt); break;
            case 2:
                printf("Qual valor? >> ");  
                scanf("%d", &v);
                bt = deleteTree(bt, v); break;             
            case 3:
                printf("Qual valor? >> ");  
                scanf("%d", &v);
                bt = delTree(bt, v); break;
            default:
                printf("Opção inválida!\n");
        }
    } while (op != 0);
    freeBinTree(bt);
    return 0;
}
