//implementação para a arvore binaria de busca simples
#include <stdio.h>
#include <stdlib.h>
#include "BinTree.h"

//função de inserção
TreeNode* insertBinTree(Tdado x, TreeNode *bt){
    TreeNode *aux;

    //verificar se o ponteiro é nulo
    if(!bt){
        //insere o novo nó
        aux = (TreeNode*)malloc(sizeof(TreeNode));
        if(!aux){
            printf("Erro: Memória insuficiente!\n");
            return bt;
        } else {
            aux->info = x;
            aux->left = NULL;
            aux->right = NULL;
            return aux;
        }

    } else if(x < bt->info){
        //x eh menor que o valor do no atual, desce pelo ramo esquerdo
        bt->left = insertBinTree(x, bt->left);  //insere no ramo esqeurdo
        return bt;

    } else {
        //x eh maior que o valor do no atual, desce pelo direito
        bt->right = insertBinTree(x, bt->right); //insere no ramo direito
        return bt;
    }
}


/*x = 8, bt = null, aux |  |
1° chamada: verificar se bt eh nulo,    cria novo nó: bt - |nó|, info = x, l = null, r = null
2° chamada: x=1, bt->8, verifica se eh menor doq 8, se for faz outra chamada recursiva que vai tentar inserir x na esquerda do bt, agora bt aponta pra 1










*/




































































