//implementação para a arvore binaria de busca simples
#include <stdio.h>
#include <stdlib.h>
#include "BinTree.h"

//função de inserção
TreeNode* insertBinTree(Tdado x, TreeNode *bt){
    TreeNode *aux;

    //verificar se o ponteiro é nulo
    if(!bt){
        //insere o novo nó
        aux = (TreeNode*)malloc(sizeof(TreeNode));
        if(!aux){
            printf("Erro: Memória insuficiente!\n");
            return bt;
        } else {
            aux->info = x;
            aux->left = NULL;
            aux->right = NULL;
            return aux;
        }

    } else if(x < bt->info){
        //x eh menor que o valor do no atual, desce pelo ramo esquerdo
        bt->left = insertBinTree(x, bt->left);  //insere no ramo esqeurdo
        return bt;

    } else {
        //x eh maior que o valor do no atual, desce pelo direito
        bt->right = insertBinTree(x, bt->right); //insere no ramo direito
        return bt;
    }
}


/*x = 8, bt = null, aux |  |
1° chamada: verificar se bt eh nulo,    cria novo nó: bt - |nó|, info = x, l = null, r = null
2° chamada: x=1, bt->8, verifica se eh menor doq 8, se for faz outra chamada recursiva que vai tentar inserir x na esquerda do bt, agora bt aponta pra 1
*/

//-------------------------------------------------------
//FUNÇÃO DE REMOÇÃO POR MERGE (PROMOÇÃO DE UM DOS FILHOS)
//-------------------------------------------------------
TreeNode *deleteTree(TreeNode *bt, Tdado x){
    TreeNode *p, *p2;
    if(bt ==  NULL) {   //arvore vazia ou chegou ao fim da arvore
        return NULL;
    } else if (bt->info == x){
        //apaga a raiz da subarvore
        if(bt->left == bt->right){
            //subarvore com apenas um elemento, a propria raiz
            free(bt);
            return NULL;
        } else if (bt->left == NULL) {  //se lado esquerdo for vazio, p = direito, apaga o bt(raiz), retorna p q vira nova raiz
            p = bt->right;
            free(bt);
            return p;
        } else if (bt->right == NULL){
            p = bt->left;
            free(bt);
            return p;
        } else {
            p2 = bt->left;
            p = p2;
            while(p->right !=NULL){
                p = p->right;            
            }
            p->right = bt->right;
            free(bt);
            return p2;
        }
    } else if (bt->info > x){
        bt->left = deleteTree(bt->left, x);
    } else {
        bt->right = deleteTree(bt->right, x);
    }
    return bt;
}

//----------------------------
// FUNÇÃO DE REMOÇÃO POR CÓPIA
//----------------------------
TreeNode* delTree(TreeNode *bt, Tdado x){
    TreeNode *t1, *temp;

    if(bt == NULL)  //chegou num nó nulo, retorna nulo
        return NULL;
    if(bt->info == x)   //achou o elemento a ser removido
        if(bt->right == NULL){
            t1 = bt->left;
            free(bt);
            return t1;
        } else if (bt->left == NULL){
            t1 = bt->right;
            free(bt);
            return t1;
        } else {
            temp = bt->right;
            while(temp->left != NULL){
                temp = temp->left;
            }
            bt->info = temp->info;
            bt->right = delTree(bt->right, temp->info);
        }
    else if (bt->info > x)
        bt->left = delTree(bt->left, x);
    else
        bt->right = delTree(bt->right, x);
    return bt;
}

//--------------------
// FUNÇÃO DE IMPRESSÃO
//--------------------
void printBinTree(const TreeNode *bt, int level){
    int i;
        
    if(!bt){            //se nulo, nao faz nada
        return;
    } else {
        //descida pela direita
        printBinTree(bt->right, level + 1);
        
        //visitação do nó
        for(i = 0; i < level; i++){
            printf("----|");
        }
        printf(BYELLOW_GREEN_BOLD);
        printf("%u\n", bt->info);
        printf(RESET);

        //descida pela esquerda
        printBinTree(bt->left, level + 1);
    }
}
/* exemplo de impressão
----|8
----|----|6
5
----|3


----|----|7
----|6
----|----|5
4
----|----|3
----|2
----|----|1




*/

void freeBinTree(TreeNode* bt){
    if(!bt)
        return;
    freeBinTree(bt->left);  //descida esquerda
    freeBinTree(bt->right); //descida direita
    free(bt);               //visita ao nó
    bt = NULL;
}

void preOrdem(TreeNode* bt){
    if(!bt)
        return;
    printf("%u ", bt->info);    //visita ao nó
    preOrdem(bt->left);         //descida esquerda
    preOrdem(bt->right);        //descida direita
}

void emOrdem(TreeNode* bt){
    if(!bt)
        return;
    emOrdem(bt->left);         //descida esquerda
    printf("%u ", bt->info);    //visita ao nó
    emOrdem(bt->right);        //descida direita
}

void posOrdem(TreeNode* bt){
    if(!bt)
        return;
    posOrdem(bt->left);         //descida esquerda
    posOrdem(bt->right);        //descida direita
    printf("%u ", bt->info);    //visita ao nó
}
/*
int main() {
    TreeNode *bt = NULL;

    bt = insertBinTree(8, bt);
    bt = insertBinTree(5, bt);
    bt = insertBinTree(3, bt);
    bt = insertBinTree(6, bt);
    bt = insertBinTree(10, bt);
    bt = insertBinTree(9, bt);
    bt = insertBinTree(12, bt);

// insercao com for
    int valores[] = {9, 4, 12, 2, 6, 10, 14, 1, 3, 5, 7, 13, 15};
    int tamanho = sizeof(valores) / sizeof(valores[0]);

    // Preenchendo a árvore
    for (int i = 0; i < tamanho; i++) {
        bt = insertBinTree(valores[i], bt);
    }

    printf("Arvore:\n");
    printBinTree(bt, 0);

    printf("\nPre-ordem: ");
    preOrdem(bt);

    printf("\nEm ordem: ");
    emOrdem(bt);

    printf("\nPos-ordem: ");
    posOrdem(bt);

    printf("\n");

    freeBinTree(bt);

    return 0;



















































