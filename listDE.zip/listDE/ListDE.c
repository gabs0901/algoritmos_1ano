//implementação das funções da lista duplamente encadeada
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "ListDE."

//inicialização da lista
void initlist(TListDE *L){
    L->first = NULL;
    L->last = NULL;
    L->len = 0;
}

//destruição da lista
void deleteList(TListDE *L){
    Tnode *aux = L->first;
    while(aux) {
        L->first = L->first->next;
        free(aux);
        aux = L->first;
    }
    L->last = NULL;
    L->len = 0;
}

//imprime a lista
void printList(TListDE L, bool dir){
    Tnode *aux;

    if(!dir){           //se dir falso, imprime o first ate o last
        printf("First-> ");
        aux = L.first;
        while(aux){
            printf("[%d]->", aux->info);
            aux = aux->next;
        }
        printf("[NULL]");
    } else {        //primeiro a gnt avanca, se nao, retrocede
        printf("Last->");
        aux = L.last;
        while(aux){
            printf("[%d]->", aux->info);
            aux = aux->prev;            
        }
        printf("[NULL]");
    }
}

//inserção pela esquerda
int insertLeft(Tdata x, TListDE *L) {
    Tnode *aux;
    aux = (Tnode*)malloc(sizeof(Tnode));    //vai pegar um endereco generico que o malloc ta voltando, transforma pra tnode e atribui pra aux
    if(aux == NULL))    //falha na alocação
        return 1;   //sinaliza com erro, deixando a lista original intacta
    else {  //insere x na lista
        aux->info = x;              //atribui x para o campo info  
        aux->next = L->first;       //insere o elemento antes do atual primeiro;
        aux->prev = NULL;           //nao tem anterior
        if(L->first != NULL)
            L->first->prev = aux;
        L->first = aux;             //faz o ponteiro do primeiro apontar para o novo no
        if(L->last == NULL)         //lista estava vazia
            L->last = aux;          //primeiro elemento eh tambem o ultimo
        L->len++;                   //incrementa o tamanho da lista
        return 0;                   //fim normal
    }
}


//inserção pela direita
int insertRight(Tdata x, TListDE *L) {
    Tnode *aux = (Tnode*)malloc(sizeof(Tnode));    
    if(aux == NULL))  
        return 1;   
    else {  
        aux->info = x;              
        aux->next = NULL;               //nao tem o proximo
        aux->prev = L->last;            //0 anterior é o antigo ultimo
        if(L->last == NULL)             //lista estava vazia
            L->first = L->last = aux;   //atualiza primeiro e ultimo
        else {                          //atualiza so o ultimo
            L->last->next = aux;        //liga o novo ultimo no
            L->last = aux;              //atualiza o ponteiro para o novo ultimo
        }
        L->len++;                       //atualiza o comprimento
        return 0;         
    }
}





/*se o malloc der certo ele aloca um bloco na memoria e faz o aux apontar para o bloco criado
se for o primeiro ele aloca nulo para o anterior e o posterior
se lfirst for != nulo ele tava apontando pra alguem
lfirst prev vai receber aux, que por sua vez ta recebendo prev do segundo colocado
o proximo a ser inputado for o novo primeiro, o anterior vira nulo e o next aponta para o next do posterior

exemplo: quero inserir o valor  x = 1, crio um aux(que eh um apontador)
1.aloca o nó
  aux aponta para o endereço da memoria alocada
  preenche o aux: aux-> = x
  aux next recebe l.first(NULO) (que ta apontando pra ninguem pq esse eh o primeiro no nulo),
  aux->prev recebe nulo pois eh o primeiro igualmente

2.se l.first == null recebe aux (que eh o endereco do 1),
  se l.last == null a lista tava vazia, se for o primeiro elemento, ele tem que ser o primeiro e o ultimo

resumindo: l.first e l.last recebem aux(que ta apontando pro primeiro e unico elemento da lista) e o contador da lista tem que ser incrementado


inserindo segundo elemento:
    cria um aux, malloc aloca um bloco, aux aponta pro bloco
    o x q quero inserir vai pro bloco, aux->next recebe l.first(vai ser o novo primerio)(next do bloco 2 recebe endereco do bloco 1)
    aux->prev recebe null pq ta inserindo a esquerda e n tem ngm antes dele
    se l.first != null, l->first->prev recebe aux(que ta contendo o endereco do bloco 2)(o anterior do 1 agora eh o 2 e o posterior do 2 eh o 1)
    l->first recebe aux (atualiza o l->first com o novo primeiro)
    incrementa a lista




*/











































