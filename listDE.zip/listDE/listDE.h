//arquivo head para lista duplamente encadeada

#include <stdbool.h>

//definicao do tipo de dado armazenado na lista
typedef int Tdata;

//definicao do tipo nó de lista encadeada
typedef struct Tnode{
    Tdata info; //dado armazenado no nó;
    struct Tnode *prev; //ponteiro para o no anterior
    struct Tnode *node; //ponteiro para o no posterior
}   Tnode;          //nome do tipo

//definicao do tipo ListaDE
typedef struct TListDE{ //nome é dispensavel
    Tnode *first;
    Tnode *last;
    int len;
}   TListDE;        //nome do tipo

//============================================================================
//funcoes da lista simplesmente encadeada
//============================================================================
//função de inicialização da lista
void initlist(TListDE *L);

//função de destruição da lista
void deleteList(TListDE *L);

//função para imprimir a lista
void printList(TListDE, bool dir);

//função de inserção pela esquerda
int insertLeft(Tdata x, TListDE *L);

//função de inserção pela direita
int insertRight(Tdata x, TListDE *L);


