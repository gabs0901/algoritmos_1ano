 //Vector.c: bib para implementar um tipo de dados vetor dinamico em c

#include <stdio.h>
#include <stdlib.h>
#include "vector.h"

//===============================================================================================
  //funções da biblioteca
//===============================================================================================

int initVector(Vector *V, int size){
    V->dados = (DADO*)malloc(size*sizeof(DADO));    //tentativa de alocar um vetor
    if(V->dados == NULL){        //se a struct for alocada dinamicamente eh referenciado por ->, se estaticamente, .
        printf("Erro: Memória insuficientemente insuficiente.\n");
        return 1;
    }
    
    V->size = size; //um eh o campo size que esta dentro de V-> dados, o outro eh o tamano que eu quis atribuir ao meu vetor
    return 0;
}

void freeVector(Vector *V){
    free(V->dados);
    printf("Vetor desalocado");
    return;
}
