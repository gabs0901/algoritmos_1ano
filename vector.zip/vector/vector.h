//Vector.h: contem as definições de tipos e variaveis para a bibçlioteca Vector.c
typedef float DADO;   //tipo de dado armazenado no vetor

typedef struct{
    int size;   //tamanho do vetor
    DADO *dados;    //conjunto do tipo dado, ponteiro para os dados armazenados na memoria
} Vector;

//funções da biblioteca
int initVector(Vector *V, int size);  //Função de inicialização

