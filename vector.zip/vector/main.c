//programa teste para o tipo vector

#include <stdio.h>
#include <stdlib.h>
#include "vector.h"

int main(){
    //declara o vetor A
    Vector A;    //tipo Vector

    //inicializa o vetor
    int res = initVector(&A, 10);
    if(!res){
        printf("Deu certo\n");
    } else {
        printf("Falha na alocação");
    }
    
    for(int i = 0; i < A.size; i++){
        A.dados[i] = i;
    }

    for(int i = 0; i < A.size; i++){
        printf("%d", A.dados[i]);
    }
    printf("\n");
    
    
    //desaloca o Vetor
    freeVector(&A);
    return 0;
}
